<?php
declare(strict_types=1);

/*
 * SevaPay local configuration.
 * Change credentials for your own environment before deployment.
 * Never use demo credentials or this configuration as-is in production.
 */
define('APP_NAME', 'SevaPay');
define('APP_ENV', 'local'); // use production only after hardening and HTTPS setup
define('BASE_URL', ''); // e.g. '/sevapay' if hosted in a subfolder
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'sevapay');
define('DB_USER', 'root');
define('DB_PASS', ''); // default XAMPP local MySQL password is often blank
define('EMAIL_ENABLED', false); // enable only after configuring a trusted mail transport
define('SMS_ENABLED', false); // adapter intentionally disabled until a provider is configured
define('PROVIDER_API_ENABLED', false); // enable only after a provider-specific, reviewed adapter is installed
define('RESET_TOKEN_MINUTES', 30);

if (APP_ENV === 'production') {
    ini_set('display_errors', '0');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
}
