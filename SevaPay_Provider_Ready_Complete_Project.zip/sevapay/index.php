<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Home';
require __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <div class="hero-copy">
    <span class="eyebrow">YOUR DIGITAL SERVICE PARTNER</span>
    <h1>One portal.<br><em>Many possibilities.</em></h1>
    <p>Manage digital service workflows from one simple partner portal. This installation runs in demo mode until you connect authorized providers.</p>
    <div class="actions"><a class="btn primary" href="<?= e(url(current_user() ? (current_user()['role'] === 'admin' ? 'admin/index.php' : 'user/index.php') : 'login.php')) ?>">Open portal →</a><a class="text-link" href="#services">Explore services ↓</a></div>
    <div class="trust-row"><span class="dot"></span> Demo environment <span>•</span> Mobile friendly <span>•</span> Role-based access</div>
  </div>
  <div class="hero-panel">
    <div class="panel-top"><span class="mini-brand">S</span><b>Partner overview</b><span class="pill">DEMO</span></div>
    <small class="muted">SAMPLE WALLET DISPLAY</small><h2>₹ 24,580.00</h2><p class="muted small">Illustrative amount only · not a real wallet</p>
    <div class="stats"><div><small>Services</small><strong>06</strong></div><div><small>Mode</small><strong>Demo</strong></div></div>
    <div class="sample-row"><span class="service-badge green">₹</span><span><b>Money Transfer</b><small>Provider integration required</small></span><span class="status">Demo</span></div>
    <div class="sample-row"><span class="service-badge blue">▦</span><span><b>AEPS</b><small>Authorized provider required</small></span><span class="status">Demo</span></div>
  </div>
</section>
<section class="section" id="services">
  <div class="section-heading"><div><span class="eyebrow">PORTAL SERVICES</span><h2>Everyday services,<br><em>within reach.</em></h2></div><p>These are workflow placeholders. No money moves and no Aadhaar, OTP, PIN or banking credentials are collected.</p></div>
  <div class="service-grid">
    <?php foreach ([['₹','Money Transfer','Domestic transfer workflow','purple'],['▦','AEPS Services','Aadhaar-enabled service placeholder','green'],['↻','Recharge','Mobile and DTH recharge','orange'],['▤','Bill Payment','Utility bill workflow','blue'],['▥','Transaction Reports','Demo-only transaction history','pink'],['?','Partner Support','Support and onboarding','teal']] as $s): ?>
    <article class="service-card"><span class="service-icon <?= e($s[3]) ?>"><?= e($s[0]) ?></span><h3><?= e($s[1]) ?></h3><p><?= e($s[2]) ?></p><span class="card-foot">Available in demo portal ↗</span></article>
    <?php endforeach; ?>
  </div>
</section>
<section class="callout"><div><span class="eyebrow">BUILT FOR PARTNERS</span><h2>A simpler service workflow.</h2><p>Create a user account to explore the dashboard, or use the administrator setup instructions in README.md.</p></div><a class="btn light" href="<?= e(url('register.php')) ?>">Create account →</a></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
