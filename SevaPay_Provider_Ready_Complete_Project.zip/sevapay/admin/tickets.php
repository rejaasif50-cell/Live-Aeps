<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$admin = require_admin();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $id = filter_input(INPUT_POST, 'ticket_id', FILTER_VALIDATE_INT);
    $status = (string)($_POST['status'] ?? 'Open');
    $reply = trim((string)($_POST['admin_reply'] ?? ''));
    $allowed = ['Open','In Progress','Resolved'];
    if (!$id || !in_array($status, $allowed, true) || mb_strlen($reply) > 4000) {
        flash('error', 'Invalid ticket update.');
    } else {
        $stmt = db()->prepare('UPDATE support_tickets SET status = ?, admin_reply = ? WHERE id = ?');
        $stmt->execute([$status, $reply !== '' ? $reply : null, $id]);
        flash('success', 'Ticket updated.');
    }
    redirect('admin/tickets.php');
}
$filter = (string)($_GET['status'] ?? 'All');
$allowedFilters = ['All','Open','In Progress','Resolved'];
if (!in_array($filter, $allowedFilters, true)) $filter = 'All';
$sql = 'SELECT t.*, u.name AS user_name, u.email AS user_email FROM support_tickets t JOIN users u ON u.id=t.user_id';
$args = []; if ($filter !== 'All') { $sql .= ' WHERE t.status = ?'; $args[] = $filter; }
$sql .= ' ORDER BY FIELD(t.status, "Open", "In Progress", "Resolved"), t.updated_at DESC LIMIT 100';
$stmt = db()->prepare($sql); $stmt->execute($args); $tickets = $stmt->fetchAll();
$pageTitle = 'Support management'; require __DIR__ . '/../includes/header.php';
?>
<div class="dash-heading"><div><span class="eyebrow">ADMINISTRATION</span><h1>Support management</h1><p class="muted">Review tickets and respond to users.</p></div><span class="pill">ADMIN</span></div>
<div class="filter-bar"><div class="filter-pills"><?php foreach ($allowedFilters as $f): ?><a class="<?= $filter === $f ? 'selected' : '' ?>" href="<?= e(url('admin/tickets.php?status=' . rawurlencode($f))) ?>"><?= e($f) ?></a><?php endforeach; ?></div><a class="btn secondary" href="<?= e(url('admin/index.php')) ?>">← Dashboard</a></div>
<section class="ticket-list"><?php if (!$tickets): ?><p class="empty">No tickets in this view.</p><?php else: ?><?php foreach ($tickets as $t): ?><article class="ticket-card"><div class="ticket-top"><strong>#<?= (int)$t['id'] ?> · <?= e($t['subject']) ?></strong><span class="status"><?= e($t['status']) ?></span></div><p class="muted small">By <?= e($t['user_name']) ?> (<?= e($t['user_email']) ?>) · <?= e($t['category']) ?> · <?= e($t['created_at']) ?></p><p><?= nl2br(e($t['message'])) ?></p><form method="post" class="form-stack ticket-update"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="ticket_id" value="<?= (int)$t['id'] ?>"><label>Status<select name="status"><?php foreach ($allowedFilters as $f): if ($f === 'All') continue; ?><option <?= $t['status'] === $f ? 'selected' : '' ?>><?= e($f) ?></option><?php endforeach; ?></select></label><label>Reply<textarea name="admin_reply" maxlength="4000" rows="3" placeholder="Write a reply to the user..."><?= e($t['admin_reply'] ?? '') ?></textarea></label><button class="btn primary" type="submit">Save response</button></form></article><?php endforeach; ?><?php endif; ?></section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
