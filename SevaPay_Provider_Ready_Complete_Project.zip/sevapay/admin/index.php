<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$admin = require_role(['admin','manager']);
$pageTitle = 'Admin dashboard';
$counts = [
  'users' => (int)db()->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn(),
  'active' => (int)db()->query("SELECT COUNT(*) FROM users WHERE status='active'")->fetchColumn(),
  'demo' => (int)db()->query("SELECT COUNT(*) FROM demo_transactions")->fetchColumn(),
  'tickets' => (int)db()->query("SELECT COUNT(*) FROM support_tickets WHERE status <> 'Resolved'")->fetchColumn(),
];
$users = db()->query('SELECT id,name,email,role,status,created_at FROM users ORDER BY id DESC LIMIT 30')->fetchAll();
$tx = db()->query('SELECT t.reference_code,t.service,t.amount,t.status,t.created_at,u.name AS user_name FROM demo_transactions t JOIN users u ON u.id=t.user_id ORDER BY t.id DESC LIMIT 15')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<div class="dash-heading"><div><span class="eyebrow">ADMINISTRATION</span><h1>Admin dashboard</h1><p class="muted">Manage user access and review demo activity.</p></div><span class="pill">ADMIN</span></div>
<div class="notice"><b>Safety:</b> all service requests are demo-only. This admin panel has no controls for real money movement or provider credentials.</div>
<div class="dash-stats"><article><small>Standard users</small><strong><?= $counts['users'] ?></strong><span>Registered accounts</span></article><article><small>Active accounts</small><strong><?= $counts['active'] ?></strong><span>All roles included</span></article><article><small>Demo requests</small><strong><?= $counts['demo'] ?></strong><span>No real transactions</span></article></div>
<div class="admin-shortcut"><a class="btn primary" href="<?= e(url('admin/tickets.php')) ?>">Manage support tickets (<?= $counts['tickets'] ?> open) →</a> <a class="btn" href="<?= e(url('admin/retailers.php')) ?>">Retailers</a> <a class="btn" href="<?= e(url('admin/reports.php')) ?>">Reports</a> <?php if($admin['role']==='admin'):?><a class="btn" href="<?=e(url('admin/roles.php'))?>">Roles</a> <a class="btn" href="<?=e(url('admin/providers.php'))?>">Provider setup</a> <a class="btn" href="<?=e(url('admin/notifications.php'))?>">Notification log</a><?php endif;?></div>
<section class="table-card"><div class="table-heading"><h2>Users</h2><span class="muted small">Latest 30 accounts</span></div><div class="table-scroll"><table><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Joined</th><th>Action</th></tr></thead><tbody>
<?php foreach ($users as $u): ?><tr><td><?= (int)$u['id'] ?></td><td><?= e($u['name']) ?></td><td><?= e($u['email']) ?></td><td><?= e($u['role']) ?></td><td><?= e($u['status']) ?></td><td><?= e($u['created_at']) ?></td><td><?php if ($admin['role']==='admin' && (int)$u['id'] !== (int)$admin['id']): ?><form method="post" action="user-status.php" class="inline-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>"><input type="hidden" name="status" value="<?= $u['status'] === 'active' ? 'disabled' : 'active' ?>"><button class="small-btn" type="submit"><?= $u['status'] === 'active' ? 'Disable' : 'Enable' ?></button></form><?php else: ?><span class="muted small">Current admin</span><?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div></section>
<section class="table-card"><div class="table-heading"><h2>Recent demo requests</h2><span class="pill">DEMO ONLY</span></div><?php if (!$tx): ?><p class="empty">No demo requests have been created.</p><?php else: ?><div class="table-scroll"><table><thead><tr><th>Reference</th><th>User</th><th>Service</th><th>Amount</th><th>Status</th><th>Created</th></tr></thead><tbody><?php foreach ($tx as $t): ?><tr><td><?= e($t['reference_code']) ?></td><td><?= e($t['user_name']) ?></td><td><?= e($t['service']) ?></td><td><?= money($t['amount']) ?></td><td><?= e($t['status']) ?></td><td><?= e($t['created_at']) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
