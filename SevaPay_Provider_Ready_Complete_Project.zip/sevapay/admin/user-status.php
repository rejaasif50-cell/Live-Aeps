<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$admin = require_role(['admin']);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('admin/index.php');
verify_csrf();
$id = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
$status = (string)($_POST['status'] ?? '');
if (!$id || $id === (int)$admin['id'] || !in_array($status, ['active','disabled'], true)) {
    flash('error', 'Invalid account status request.');
    redirect('admin/index.php');
}
$stmt = db()->prepare("UPDATE users SET status = ? WHERE id = ? AND role = 'user'");
$stmt->execute([$status, $id]);
flash('success', $stmt->rowCount() ? 'User status updated.' : 'No user account was changed.');
redirect('admin/index.php');
