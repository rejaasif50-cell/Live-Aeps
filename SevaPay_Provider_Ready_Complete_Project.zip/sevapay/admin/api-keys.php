<?php
require_once __DIR__.'/../includes/bootstrap.php';
$admin=require_role(['admin']);
$pageTitle='API Keys';
$generatedKey=$_SESSION['new_api_key']??null; unset($_SESSION['new_api_key']);
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf();
 $action=(string)($_POST['action']??'');
 if($action==='create'){
  $name=trim((string)($_POST['name']??'')); $scope=(string)($_POST['scope']??'read');
  if($name===''||mb_strlen($name)>100||!in_array($scope,['read','demo'],true)) { flash('error','Enter a valid key name and scope.'); redirect('admin/api-keys.php'); }
  $raw='sp_live_'.bin2hex(random_bytes(24)); $prefix=substr($raw,0,14); $hash=hash('sha256',$raw);
  $q=db()->prepare('INSERT INTO api_keys(name,key_prefix,key_hash,scope,created_by) VALUES(?,?,?,?,?)'); $q->execute([$name,$prefix,$hash,$scope,$admin['id']]);
  $_SESSION['new_api_key']=$raw; audit('api_key_created','Created API key '.$name.' with '.$scope.' scope'); flash('success','API key created. Copy it now; it will not be shown again.'); redirect('admin/api-keys.php');
 }
 if($action==='revoke'){
  $id=(int)($_POST['id']??0); $q=db()->prepare("UPDATE api_keys SET status='revoked' WHERE id=?"); $q->execute([$id]); audit('api_key_revoked','Revoked API key #'.$id); flash('success','API key revoked.'); redirect('admin/api-keys.php');
 }
}
$keys=db()->query('SELECT id,name,key_prefix,scope,status,last_used_at,created_at FROM api_keys ORDER BY id DESC')->fetchAll();
$logs=db()->query('SELECT l.endpoint,l.http_method,l.response_code,l.request_id,l.created_at,k.name AS key_name FROM api_request_logs l LEFT JOIN api_keys k ON k.id=l.api_key_id ORDER BY l.id DESC LIMIT 30')->fetchAll();
require __DIR__.'/../includes/header.php';
?>
<div class="dash-heading"><div><span class="eyebrow">DEVELOPER SETTINGS</span><h1>REST API keys</h1><p class="muted">Keys authenticate the local JSON API. Demo scope can create demo-only records, never live financial transactions.</p></div><span class="pill">LIVE CALLS DISABLED</span></div>
<?php if($generatedKey): ?><section class="notice"><b>Copy this key now — it is shown only once.</b><p><code id="newApiKey"><?=e($generatedKey)?></code></p><button class="btn" type="button" onclick="navigator.clipboard.writeText(document.getElementById('newApiKey').innerText)">Copy API key</button><p class="muted">Store it securely. The database stores only a SHA-256 hash.</p></section><?php endif; ?>
<section class="table-card"><h2>Create API key</h2><form method="post" class="stack-form"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="create"><label>Key name<input name="name" maxlength="100" required placeholder="My integration"></label><label>Scope<select name="scope"><option value="read">Read only (health and services)</option><option value="demo">Demo (read + create demo request)</option></select></label><button class="btn primary" type="submit">Generate API key</button></form></section>
<section class="table-card"><h2>API keys</h2><div class="table-scroll"><table><thead><tr><th>Name</th><th>Prefix</th><th>Scope</th><th>Status</th><th>Last used</th><th>Created</th><th>Action</th></tr></thead><tbody><?php foreach($keys as $k): ?><tr><td><?=e($k['name'])?></td><td><code><?=e($k['key_prefix'])?>…</code></td><td><?=e($k['scope'])?></td><td><?=e($k['status'])?></td><td><?=e($k['last_used_at']??'Never')?></td><td><?=e($k['created_at'])?></td><td><?php if($k['status']==='active'): ?><form method="post" onsubmit="return confirm('Revoke this key?')"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="revoke"><input type="hidden" name="id" value="<?= (int)$k['id'] ?>"><button class="btn" type="submit">Revoke</button></form><?php else: ?>—<?php endif; ?></td></tr><?php endforeach; ?><?php if(!$keys): ?><tr><td colspan="7">No API keys yet.</td></tr><?php endif; ?></tbody></table></div></section>
<section class="table-card"><h2>Recent API requests</h2><div class="table-scroll"><table><thead><tr><th>Time</th><th>Key</th><th>Endpoint</th><th>Method</th><th>HTTP</th><th>Request ID</th></tr></thead><tbody><?php foreach($logs as $l): ?><tr><td><?=e($l['created_at'])?></td><td><?=e($l['key_name']??'revoked/deleted key')?></td><td><?=e($l['endpoint'])?></td><td><?=e($l['http_method'])?></td><td><?= (int)$l['response_code'] ?></td><td><?=e($l['request_id'])?></td></tr><?php endforeach; ?><?php if(!$logs): ?><tr><td colspan="6">No API requests logged yet.</td></tr><?php endif; ?></tbody></table></div></section>
<section class="table-card"><h2>Quick API test</h2><p>Set the key in an environment variable or request header. Do not paste it into public code or screenshots.</p><pre><code>curl -H "X-API-Key: YOUR_API_KEY" "http://localhost/sevapay/api/v1/health.php"
curl -H "X-API-Key: YOUR_API_KEY" "http://localhost/sevapay/api/v1/services.php"
curl -X POST -H "X-API-Key: YOUR_DEMO_SCOPE_KEY" -H "Content-Type: application/json" -d "{\"service\":\"Recharge\"}" "http://localhost/sevapay/api/v1/demo-request.php"</code></pre><p class="muted">POST request only records a DEMO ONLY event with amount 0.00.</p></section>
<?php require __DIR__.'/../includes/footer.php'; ?>
