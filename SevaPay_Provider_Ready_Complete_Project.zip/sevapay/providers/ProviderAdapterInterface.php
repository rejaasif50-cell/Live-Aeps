<?php
declare(strict_types=1);

/** Provider-specific adapter contract. Implement only against the chosen provider's official docs. */
interface ProviderAdapterInterface
{
    /** @return array{provider_reference:string,status:string,message?:string} */
    public function initiate(string $service, array $payload, string $idempotencyKey): array;

    /** @return array{provider_reference:string,status:string,message?:string} */
    public function status(string $providerReference): array;

    /** Verify provider signature and normalize a webhook event. */
    public function verifyWebhook(string $rawBody, array $headers): array;
}
