<?php
declare(strict_types=1);
require_once __DIR__.'/ProviderAdapterInterface.php';

/** Fail-closed registry. No adapter is bundled because no provider was selected. */
final class ProviderRegistry
{
    public static function get(): ?ProviderAdapterInterface
    {
        if (!defined('PROVIDER_API_ENABLED') || PROVIDER_API_ENABLED !== true) return null;
        $adapterFile = __DIR__ . '/ActiveProviderAdapter.php';
        if (!is_file($adapterFile)) return null;
        require_once $adapterFile;
        if (!class_exists('ActiveProviderAdapter')) return null;
        $adapter = new ActiveProviderAdapter();
        return $adapter instanceof ProviderAdapterInterface ? $adapter : null;
    }
}
