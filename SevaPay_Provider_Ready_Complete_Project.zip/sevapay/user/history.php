<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$me = require_login();
if (in_array($me['role'], ['admin','manager','support'], true)) redirect('admin/index.php');
$q = trim((string)($_GET['q'] ?? ''));
$sql = 'SELECT reference_code, service, amount, status, created_at FROM demo_transactions WHERE user_id = ?';
$args = [$me['id']];
if ($q !== '') { $sql .= ' AND (reference_code LIKE ? OR service LIKE ? OR status LIKE ?)'; $like = '%' . $q . '%'; array_push($args, $like, $like, $like); }
$sql .= ' ORDER BY id DESC LIMIT 200';
$stmt = db()->prepare($sql); $stmt->execute($args); $rows = $stmt->fetchAll();
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="sevapay-demo-history.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Reference', 'Service', 'Amount INR', 'Status', 'Created']);
    foreach ($rows as $r) fputcsv($out, [$r['reference_code'], $r['service'], $r['amount'], $r['status'], $r['created_at']]);
    fclose($out); exit;
}
$pageTitle = 'Demo request history'; require __DIR__ . '/../includes/header.php';
?>
<div class="dash-heading"><div><span class="eyebrow">ACTIVITY</span><h1>Request history</h1><p class="muted">Your latest 200 demo records. These are not real transactions.</p></div><span class="pill">DEMO ONLY</span></div>
<div class="filter-bar"><form method="get" class="search-form"><input name="q" value="<?= e($q) ?>" placeholder="Search reference, service or status"><button class="btn primary" type="submit">Search</button></form><a class="btn secondary" href="<?= e(url('user/history.php?' . http_build_query(['q'=>$q,'export'=>'csv']))) ?>">Export CSV</a></div>
<section class="table-card"><div class="table-heading"><h2>Demo requests</h2><span class="muted small"><?= count($rows) ?> records shown</span></div><?php if (!$rows): ?><p class="empty">No matching demo requests found.</p><?php else: ?><div class="table-scroll"><table><thead><tr><th>Reference</th><th>Service</th><th>Amount</th><th>Status</th><th>Created</th></tr></thead><tbody><?php foreach ($rows as $r): ?><tr><td><?= e($r['reference_code']) ?></td><td><?= e($r['service']) ?></td><td><?= money($r['amount']) ?></td><td><span class="status"><?= e($r['status']) ?></span></td><td><?= e($r['created_at']) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
