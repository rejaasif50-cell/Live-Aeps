<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$me = require_login();
if (in_array($me['role'], ['admin','manager','support'], true)) redirect('admin/index.php');
$pageTitle = 'User dashboard';
$services = ['Money Transfer','AEPS Services','Recharge','Bill Payment'];
$stmt = db()->prepare('SELECT id, service, reference_code, amount, status, created_at FROM demo_transactions WHERE user_id = ? ORDER BY id DESC LIMIT 10');
$stmt->execute([$me['id']]);
$transactions = $stmt->fetchAll();
$ticketStmt = db()->prepare("SELECT COUNT(*) FROM support_tickets WHERE user_id = ? AND status <> 'Resolved'");
$ticketStmt->execute([$me['id']]);
$openTickets = (int)$ticketStmt->fetchColumn();
require __DIR__ . '/../includes/header.php';
?>
<div class="dash-heading"><div><span class="eyebrow">PARTNER WORKSPACE</span><h1>Hello, <?= e($me['name']) ?>.</h1><p class="muted">Here is your demo account overview.</p></div><span class="pill">DEMO MODE</span></div>
<div class="notice"><b>Demo mode is active.</b> Service actions below create a clearly labelled demo record only. They do not send money, debit a wallet or contact a financial provider.</div>
<div class="dash-stats"><article><small>Wallet balance</small><strong>₹0.00</strong><span>Not connected</span></article><article><small>Demo requests</small><strong><?= count($transactions) ?></strong><span>Recent records shown below</span></article><article><small>Account status</small><strong>Active</strong><span>Standard user access</span></article></div>
<div class="quick-links">
<a href="<?= e(url('user/history.php')) ?>"><strong>Transaction history</strong><span>Search all demo requests →</span></a>
<a href="<?= e(url('user/tickets.php')) ?>"><strong>Support tickets</strong><span><?= $openTickets ?> open or in-progress →</span></a>
<a href="<?= e(url('user/profile.php')) ?>"><strong>My profile</strong><span>Update your account details →</span></a>
</div>
<section class="section compact"><div class="section-heading"><div><span class="eyebrow">AVAILABLE WORKFLOWS</span><h2>Choose a service</h2></div></div>
<div class="service-grid">
<?php foreach ($services as $service): ?><form class="service-action" method="post" action="demo-service.php"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="service" value="<?= e($service) ?>"><span class="service-icon green"><?= $service === 'Money Transfer' ? '₹' : ($service === 'AEPS Services' ? '▦' : ($service === 'Recharge' ? '↻' : '▤')) ?></span><h3><?= e($service) ?></h3><p>Create a demo-only request record.</p><button class="btn secondary full" type="submit">Open demo workflow →</button></form><?php endforeach; ?>
</div></section>
<section class="table-card"><div class="table-heading"><h2>Recent demo requests</h2><span class="pill">NOT REAL TRANSACTIONS</span></div>
<?php if (!$transactions): ?><p class="empty">No demo requests yet. Choose a service above to create one.</p><?php else: ?><div class="table-scroll"><table><thead><tr><th>Reference</th><th>Service</th><th>Amount</th><th>Status</th><th>Created</th></tr></thead><tbody><?php foreach ($transactions as $t): ?><tr><td><?= e($t['reference_code']) ?></td><td><?= e($t['service']) ?></td><td><?= money($t['amount']) ?></td><td><span class="status"><?= e($t['status']) ?></span></td><td><?= e($t['created_at']) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
