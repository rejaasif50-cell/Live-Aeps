<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$me = require_login();
if (in_array($me['role'], ['admin','manager','support'], true)) redirect('admin/tickets.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $subject = trim((string)($_POST['subject'] ?? ''));
    $category = (string)($_POST['category'] ?? 'Other');
    $message = trim((string)($_POST['message'] ?? ''));
    $categories = ['Account','Demo service','Technical issue','Other'];
    if (mb_strlen($subject) < 4 || mb_strlen($subject) > 140 || mb_strlen($message) < 10 || mb_strlen($message) > 4000 || !in_array($category, $categories, true)) {
        flash('error', 'Check the subject, category and message. Message must be 10 to 4000 characters.');
    } else {
        $stmt = db()->prepare('INSERT INTO support_tickets (user_id, subject, category, message) VALUES (?,?,?,?)');
        $stmt->execute([$me['id'], $subject, $category, $message]);
        flash('success', 'Support ticket created.');
    }
    redirect('user/tickets.php');
}
$stmt = db()->prepare('SELECT id, subject, category, message, admin_reply, status, created_at, updated_at FROM support_tickets WHERE user_id = ? ORDER BY id DESC LIMIT 100');
$stmt->execute([$me['id']]); $tickets = $stmt->fetchAll();
$pageTitle = 'Support tickets'; require __DIR__ . '/../includes/header.php';
?>
<div class="dash-heading"><div><span class="eyebrow">HELP CENTRE</span><h1>Support tickets</h1><p class="muted">Create a ticket for account or demo portal issues.</p></div><span class="pill">SUPPORT</span></div>
<div class="notice"><b>Privacy reminder:</b> do not include passwords, OTPs, PINs, Aadhaar details, card numbers or banking credentials in a support message.</div>
<section class="auth-wrap"><div class="auth-card"><h2>Open a ticket</h2><form method="post" class="form-stack"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><label>Subject<input name="subject" minlength="4" maxlength="140" required placeholder="Briefly describe the issue"></label><label>Category<select name="category"><option>Account</option><option>Demo service</option><option>Technical issue</option><option>Other</option></select></label><label>Message<textarea name="message" minlength="10" maxlength="4000" rows="5" required placeholder="Describe what happened..."></textarea></label><button class="btn primary full" type="submit">Submit ticket</button></form></div></section>
<section class="ticket-list"><h2>Your tickets</h2><?php if (!$tickets): ?><p class="empty">You have not created any tickets yet.</p><?php else: ?><?php foreach ($tickets as $t): ?><article class="ticket-card"><div class="ticket-top"><strong>#<?= (int)$t['id'] ?> · <?= e($t['subject']) ?></strong><span class="status"><?= e($t['status']) ?></span></div><p class="muted small"><?= e($t['category']) ?> · Created <?= e($t['created_at']) ?></p><p><?= nl2br(e($t['message'])) ?></p><?php if ($t['admin_reply']): ?><div class="reply"><b>Admin reply</b><p><?= nl2br(e($t['admin_reply'])) ?></p></div><?php endif; ?></article><?php endforeach; ?><?php endif; ?></section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
