<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$me = require_login();
if (in_array($me['role'], ['admin','manager','support'], true)) redirect('admin/index.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim((string)($_POST['name'] ?? ''));
    if (mb_strlen($name) < 2 || mb_strlen($name) > 100) {
        flash('error', 'Name must be between 2 and 100 characters.');
    } else {
        $stmt = db()->prepare('UPDATE users SET name = ? WHERE id = ?');
        $stmt->execute([$name, $me['id']]);
        flash('success', 'Profile updated.');
    }
    redirect('user/profile.php');
}
$pageTitle = 'My profile';
require __DIR__ . '/../includes/header.php';
?>
<div class="dash-heading"><div><span class="eyebrow">ACCOUNT SETTINGS</span><h1>My profile</h1><p class="muted">Manage your basic account information.</p></div><span class="pill">USER ACCOUNT</span></div>
<section class="auth-wrap"><div class="auth-card"><h2>Profile details</h2><p class="muted">Your email is used for login and cannot be changed here.</p><form method="post" class="form-stack"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><label>Full name<input name="name" value="<?= e($me['name']) ?>" minlength="2" maxlength="100" required></label><label>Email address<input value="<?= e($me['email']) ?>" disabled></label><label>Account created<input value="<?= e($me['created_at']) ?>" disabled></label><button class="btn primary full" type="submit">Save profile</button></form><a class="inline-link" href="<?= e(url('user/index.php')) ?>">← Back to dashboard</a></div></section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
