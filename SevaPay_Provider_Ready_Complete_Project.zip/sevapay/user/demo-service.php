<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$me = require_login();
if (in_array($me['role'], ['admin','manager','support'], true)) redirect('admin/index.php');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('user/index.php');
verify_csrf();
$allowed = ['Money Transfer','AEPS Services','Recharge','Bill Payment'];
$service = (string)($_POST['service'] ?? '');
if (!in_array($service, $allowed, true)) {
    flash('error', 'Unknown demo service.');
    redirect('user/index.php');
}
$ref = 'DEMO-' . strtoupper(bin2hex(random_bytes(4)));
$stmt = db()->prepare('INSERT INTO demo_transactions (user_id, service, reference_code, amount, status) VALUES (?,?,?,?,?)');
$stmt->execute([$me['id'], $service, $ref, 0.00, 'DEMO ONLY']);
create_demo_ledger_note((int)$me['id'], $ref, 'Demo request logged for ' . $service . '; no funds moved.');
audit('demo_service_request', 'User #' . $me['id'] . ' created ' . $service . ' ' . $ref);
flash('success', 'Demo request created: ' . $ref . '. No transaction was processed.');
redirect('user/index.php');
