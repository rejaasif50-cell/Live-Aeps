<?php
declare(strict_types=1);
require_once __DIR__.'/_common.php';
if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST') api_json(405,['ok'=>false,'error'=>'method_not_allowed']);
$key=api_auth('demo');
$contentType=strtolower(trim(explode(';',$_SERVER['CONTENT_TYPE']??'')[0]));
if($contentType!=='application/json') api_finish(415,['ok'=>false,'error'=>'content_type_must_be_application_json'],(int)$key['id']);
$raw=file_get_contents('php://input'); if($raw===false||strlen($raw)>4096) api_finish(413,['ok'=>false,'error'=>'request_too_large'],(int)$key['id']);
$payload=json_decode($raw,true); if(!is_array($payload)) api_finish(400,['ok'=>false,'error'=>'invalid_json'],(int)$key['id']);
$map=['money_transfer'=>'Money Transfer','aeps'=>'AEPS Services','recharge'=>'Recharge','bill_payment'=>'Bill Payment'];
$serviceCode=(string)($payload['service']??''); if(!isset($map[$serviceCode])) api_finish(422,['ok'=>false,'error'=>'unsupported_service','allowed_services'=>array_keys($map)],(int)$key['id']);
// The REST endpoint is intentionally a demo simulator. It does not accept amounts, bank details or customer secrets.
$reference='API-DEMO-'.strtoupper(bin2hex(random_bytes(5)));
api_finish(201,['ok'=>true,'mode'=>'DEMO_ONLY','reference'=>$reference,'service'=>$map[$serviceCode],'amount'=>'0.00','status'=>'DEMO ONLY','message'=>'Demo request recorded. No provider was called and no funds moved.'],(int)$key['id']);
