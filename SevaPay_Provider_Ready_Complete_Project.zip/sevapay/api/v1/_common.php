<?php
declare(strict_types=1);
require_once __DIR__.'/../../includes/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
$requestId='req_'.bin2hex(random_bytes(8));
function api_json(int $status,array $data): never { global $requestId; http_response_code($status); $data['request_id']=$requestId; echo json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); exit; }
function api_auth(string $requiredScope='read'): array {
 global $requestId;
 $key=$_SERVER['HTTP_X_API_KEY']??'';
 if(!is_string($key)||strlen($key)<20||strlen($key)>200){ api_log(null,$requiredScope==='demo'?'/api/v1/demo-request.php':(parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/'),$_SERVER['REQUEST_METHOD']??'GET',401,$requestId); api_json(401,['ok'=>false,'error'=>'missing_or_invalid_api_key']); }
 $q=db()->prepare("SELECT id,name,scope,status FROM api_keys WHERE key_hash=? LIMIT 1"); $q->execute([hash('sha256',$key)]); $row=$q->fetch();
 if(!$row||$row['status']!=='active'||($requiredScope==='demo'&&$row['scope']!=='demo')){ api_log($row?(int)$row['id']:null,parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/',$_SERVER['REQUEST_METHOD']??'GET',403,$requestId); api_json(403,['ok'=>false,'error'=>'api_key_not_authorized']); }
 db()->prepare('UPDATE api_keys SET last_used_at=NOW() WHERE id=?')->execute([(int)$row['id']]);
 return $row;
}
function api_log(?int $keyId,string $endpoint,string $method,int $status,string $requestId): void { try{$q=db()->prepare('INSERT INTO api_request_logs(api_key_id,endpoint,http_method,response_code,request_id) VALUES(?,?,?,?,?)');$q->execute([$keyId,substr($endpoint,0,190),substr($method,0,10),$status,$requestId]);}catch(Throwable $e){} }
function api_finish(int $status,array $body,?int $keyId=null): never { global $requestId; api_log($keyId,parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/',$_SERVER['REQUEST_METHOD']??'GET',$status,$requestId); api_json($status,$body); }
