<?php
declare(strict_types=1);
require_once __DIR__.'/../../includes/bootstrap.php';
require_once __DIR__.'/../../providers/ProviderRegistry.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') { http_response_code(405); echo json_encode(['ok'=>false,'error'=>'method_not_allowed']); exit; }
$raw=file_get_contents('php://input');
if ($raw===false || strlen($raw)>65536) { http_response_code(413); echo json_encode(['ok'=>false,'error'=>'request_too_large']); exit; }
$adapter=ProviderRegistry::get();
if (!$adapter) { http_response_code(503); echo json_encode(['ok'=>false,'error'=>'provider_not_configured','message'=>'Webhook rejected because no provider adapter/signature verifier is configured.']); exit; }
try {
  $event=$adapter->verifyWebhook($raw,function_exists('getallheaders')?getallheaders():[]);
  if (empty($event['event_id']) || empty($event['provider_reference']) || empty($event['status'])) throw new RuntimeException('Webhook event invalid.');
  // The provider-specific adapter must verify signature, timestamp/replay window and normalize status.
  // Persisting/reconciling normalized events is intentionally not generic: implement per provider contract.
  http_response_code(202); echo json_encode(['ok'=>true,'verified'=>true,'event_id'=>(string)$event['event_id'],'provider_reference'=>(string)$event['provider_reference'],'status'=>(string)$event['status'],'message'=>'Signature verifier accepted the event; persist/reconcile this normalized event in the provider-specific adapter before production use.']);
} catch(Throwable $e) {
  error_log('SevaPay webhook rejected; type='.get_class($e)); http_response_code(401); echo json_encode(['ok'=>false,'error'=>'webhook_verification_failed']);
}
