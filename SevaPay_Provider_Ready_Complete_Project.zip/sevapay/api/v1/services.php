<?php
require_once __DIR__.'/_common.php';
if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET') api_json(405,['ok'=>false,'error'=>'method_not_allowed']);
$key=api_auth('read');
api_finish(200,['ok'=>true,'mode'=>'DEMO_ONLY','services'=>[['code'=>'money_transfer','name'=>'Money Transfer','live_enabled'=>false],['code'=>'aeps','name'=>'AEPS','live_enabled'=>false],['code'=>'recharge','name'=>'Recharge','live_enabled'=>false],['code'=>'bill_payment','name'=>'Bill Payment','live_enabled'=>false]]],(int)$key['id']);
