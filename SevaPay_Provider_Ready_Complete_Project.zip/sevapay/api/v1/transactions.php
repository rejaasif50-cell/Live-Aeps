<?php
declare(strict_types=1);
require_once __DIR__.'/_common.php';
require_once __DIR__.'/../../providers/ProviderRegistry.php';
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') api_json(405,['ok'=>false,'error'=>'method_not_allowed']);
$key = api_auth('demo');
$contentType = strtolower(trim(explode(';', $_SERVER['CONTENT_TYPE'] ?? '')[0]));
if ($contentType !== 'application/json') api_finish(415,['ok'=>false,'error'=>'content_type_must_be_application_json'],(int)$key['id']);
$raw = file_get_contents('php://input');
if ($raw === false || strlen($raw) > 8192) api_finish(413,['ok'=>false,'error'=>'request_too_large'],(int)$key['id']);
$body = json_decode($raw, true);
if (!is_array($body)) api_finish(400,['ok'=>false,'error'=>'invalid_json'],(int)$key['id']);
$services = ['mobile_recharge','dth_recharge','money_transfer','aeps','bbps'];
$service = (string)($body['service'] ?? '');
if (!in_array($service, $services, true)) api_finish(422,['ok'=>false,'error'=>'unsupported_service','allowed_services'=>$services],(int)$key['id']);
// Do not accept OTP, Aadhaar biometric/PIN, UPI PIN, card PIN, bank passwords or raw payment credentials.
$forbidden = ['otp','aadhaar','aadhaar_number','biometric','pid_data','upi_pin','pin','card_pin','bank_password','password'];
foreach ($forbidden as $field) {
    if (array_key_exists($field, $body)) api_finish(422,['ok'=>false,'error'=>'sensitive_auth_data_not_accepted','field'=>$field],(int)$key['id']);
}
$adapter = ProviderRegistry::get();
if (!$adapter) api_finish(503,[
    'ok'=>false,'error'=>'provider_not_configured',
    'mode'=>'LIVE_DISABLED',
    'message'=>'No authorized provider adapter is installed. No transaction was created and no provider was contacted.',
    'required_next_step'=>'Select an authorized provider and implement its official API contract, authentication, status verification and webhook signature validation.'
],(int)$key['id']);
$idempotency = trim((string)($_SERVER['HTTP_IDEMPOTENCY_KEY'] ?? ''));
if ($idempotency === '' || strlen($idempotency) < 12 || strlen($idempotency) > 128 || !preg_match('/^[A-Za-z0-9._:-]+$/',$idempotency)) {
    api_finish(400,['ok'=>false,'error'=>'valid_idempotency_key_required','header'=>'Idempotency-Key'],(int)$key['id']);
}
try {
    $result = $adapter->initiate($service, $body, $idempotency);
    if (empty($result['provider_reference']) || empty($result['status'])) throw new RuntimeException('Provider adapter returned an invalid response.');
    api_finish(202,['ok'=>true,'mode'=>'PROVIDER_ADAPTER','service'=>$service,'provider_reference'=>(string)$result['provider_reference'],'status'=>(string)$result['status'],'message'=>(string)($result['message'] ?? 'Request accepted; verify status before reporting success.')],(int)$key['id']);
} catch (Throwable $e) {
    error_log('SevaPay provider initiate error; request_id='.$requestId.'; type='.get_class($e));
    api_finish(502,['ok'=>false,'error'=>'provider_request_failed','message'=>'Provider request failed or returned an invalid response. Check server logs using request_id. Do not retry with a new idempotency key until status is reconciled.'],(int)$key['id']);
}
