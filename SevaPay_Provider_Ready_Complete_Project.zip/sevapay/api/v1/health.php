<?php
require_once __DIR__.'/_common.php';
if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET') api_json(405,['ok'=>false,'error'=>'method_not_allowed']);
$key=api_auth('read');
api_finish(200,['ok'=>true,'service'=>'SevaPay Demo API','version'=>'1.0','mode'=>'DEMO_ONLY','live_financial_operations'=>false],(int)$key['id']);
