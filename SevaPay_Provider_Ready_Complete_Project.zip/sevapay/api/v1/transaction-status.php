<?php
declare(strict_types=1);
require_once __DIR__.'/_common.php';
require_once __DIR__.'/../../providers/ProviderRegistry.php';
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') api_json(405,['ok'=>false,'error'=>'method_not_allowed']);
$key=api_auth('read');
$reference=trim((string)($_GET['reference'] ?? ''));
if ($reference==='' || strlen($reference)>160 || !preg_match('/^[A-Za-z0-9._:-]+$/',$reference)) api_finish(400,['ok'=>false,'error'=>'valid_reference_required'],(int)$key['id']);
$adapter=ProviderRegistry::get();
if (!$adapter) api_finish(503,['ok'=>false,'error'=>'provider_not_configured','mode'=>'LIVE_DISABLED','message'=>'Status cannot be verified because no authorized provider adapter is configured.'],(int)$key['id']);
try {
  $result=$adapter->status($reference);
  if (empty($result['status'])) throw new RuntimeException('Provider status response invalid.');
  api_finish(200,['ok'=>true,'provider_reference'=>(string)($result['provider_reference']??$reference),'status'=>(string)$result['status'],'message'=>(string)($result['message']??'Status returned by configured provider adapter.')],(int)$key['id']);
} catch(Throwable $e) {
  error_log('SevaPay provider status error; request_id='.$requestId.'; type='.get_class($e));
  api_finish(502,['ok'=>false,'error'=>'provider_status_check_failed','message'=>'Could not verify provider status. Treat the transaction as unknown until reconciled.'],(int)$key['id']);
}
