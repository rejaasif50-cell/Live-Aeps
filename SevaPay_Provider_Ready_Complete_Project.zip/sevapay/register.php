<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (current_user()) redirect('user/index.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim((string)($_POST['name'] ?? ''));
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    if (mb_strlen($name) < 2 || mb_strlen($name) > 100) $error = 'Name must be 2 to 100 characters.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) $error = 'Enter a valid email address.';
    elseif (strlen($password) < 10) $error = 'Password must be at least 10 characters.';
    else {
        try {
            $stmt = db()->prepare('INSERT INTO users (name,email,password_hash,role,status) VALUES (?,?,?,"user","active")');
            $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
            flash('success', 'Account created. Please sign in.');
            redirect('login.php');
        } catch (PDOException $ex) {
            if ($ex->getCode() === '23000') $error = 'An account with this email already exists.';
            else throw $ex;
        }
    }
}
$pageTitle = 'Create account';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-wrap"><section class="auth-card"><span class="modal-logo">S</span><span class="eyebrow">JOIN SEVAPAY</span><h1 class="auth-title">Create your account</h1><p class="muted">Registration creates a standard user account only.</p>
<?php if ($error): ?><div class="flash error"><?= e($error) ?></div><?php endif; ?>
<form method="post" class="form-stack"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<label>Full name<input name="name" required minlength="2" maxlength="100" autocomplete="name"></label>
<label>Email address<input type="email" name="email" required maxlength="190" autocomplete="email"></label>
<label>Password<input type="password" name="password" required minlength="10" autocomplete="new-password"><small>Use at least 10 characters.</small></label>
<button class="btn primary full" type="submit">Create account →</button></form>
<p class="muted small">Already registered? <a class="inline-link" href="<?= e(url('login.php')) ?>">Sign in</a></p>
</section></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
