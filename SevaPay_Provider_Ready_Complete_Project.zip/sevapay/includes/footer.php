</main>
<footer class="footer">
  <a class="brand" href="<?= e(url('index.php')) ?>"><span class="brand-mark">S</span><span><strong>SevaPay</strong><small>Digital Services Portal</small></span></a>
  <p>Demo portal only. Financial services are not connected to live providers.</p>
  <span>© <?= date('Y') ?> SevaPay</span>
</footer>
<script src="<?= e(url('assets/app.js')) ?>"></script>
</body>
</html>
