<?php
require_once __DIR__ . '/bootstrap.php';
$pageTitle = $pageTitle ?? APP_NAME;
$me = current_user();
$flashMessage = get_flash();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#0f766e">
<link rel="manifest" href="<?= e(url('manifest.webmanifest')) ?>">
<link rel="icon" href="<?= e(url('assets/icon.svg')) ?>" type="image/svg+xml">
<title><?= e($pageTitle) ?> · <?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="<?= e(url('assets/style.css')) ?>">
</head>
<body>
<header class="topbar">
  <a class="brand" href="<?= e(url('index.php')) ?>"><span class="brand-mark">S</span><span><strong>SevaPay</strong><small>Digital Services Portal</small></span></a>
  <nav>
    <a href="<?= e(url('index.php#services')) ?>">Services</a>
    <?php if ($me): ?>
      <a href="<?= e(url($me['role']==='support' ? 'admin/tickets.php' : (in_array($me['role'], ['admin','manager'], true) ? 'admin/index.php' : 'user/index.php'))) ?>">Dashboard</a>
      <?php if (!in_array($me['role'], ['admin','manager','support'], true)): ?><a href="<?= e(url('user/wallet.php')) ?>">Demo Wallet</a><?php endif; ?>
      <?php if (in_array($me['role'], ['admin','manager'], true)): ?><a href="<?= e(url('admin/retailers.php')) ?>">Retailers</a><a href="<?= e(url('admin/reports.php')) ?>">Reports</a><?php endif; ?>
      <?php if ($me['role']==='admin'): ?><a href="<?= e(url('admin/providers.php')) ?>">Providers</a><a href="<?= e(url('admin/api-keys.php')) ?>">API Keys</a><a href="<?= e(url('admin/roles.php')) ?>">Roles</a><?php endif; ?>
      <?php if ($me['role']==='support'): ?><a href="<?= e(url('admin/tickets.php')) ?>">Support</a><?php elseif (!in_array($me['role'], ['admin','manager'], true)): ?><a href="<?= e(url('user/tickets.php')) ?>">Support</a><?php endif; ?>
      <a href="<?= e(url('user/profile.php')) ?>">Profile</a>
      <a href="<?= e(url('logout.php')) ?>">Sign out</a>
    <?php else: ?>
      <a href="<?= e(url('login.php')) ?>">Login</a>
      <a class="nav-cta" href="<?= e(url('register.php')) ?>">Create account</a>
    <?php endif; ?>
  </nav>
</header>
<?php if ($flashMessage): ?>
  <div class="flash <?= e($flashMessage['kind']) ?>"><?= e($flashMessage['message']) ?></div>
<?php endif; ?>
<main class="main">
