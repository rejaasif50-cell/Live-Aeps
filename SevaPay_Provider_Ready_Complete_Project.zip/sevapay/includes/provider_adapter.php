<?php
declare(strict_types=1);
require_once __DIR__.'/bootstrap.php';
/**
 * Deliberately fail-closed provider boundary. No outbound HTTP requests are made by this starter.
 * Implement a provider-specific, reviewed adapter only after authorization and sandbox certification.
 */
function provider_is_enabled(): bool {
    return defined('PROVIDER_API_ENABLED') && PROVIDER_API_ENABLED === true;
}
function provider_submit_demo_request(string $service, array $payload = []): never {
    if (!provider_is_enabled()) {
        throw new RuntimeException('Provider API integration is disabled. Only demo requests are allowed.');
    }
    // Intentionally unimplemented: a generic adapter cannot safely guess a provider's auth/signature scheme.
    throw new RuntimeException('No provider adapter is implemented. Do not enable live financial operations.');
}
