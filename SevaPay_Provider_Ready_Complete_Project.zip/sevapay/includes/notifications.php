<?php
// Integration boundary: email is disabled by default and uses PHP mail() only if explicitly enabled.
// SMS requires a separately reviewed provider adapter. Never log OTPs, passwords, PINs or API secrets.
function send_sms_placeholder(?int $userId, string $phone, string $message): void {
    log_notification($userId, 'sms', $phone, 'SMS notification', $message, 'DISABLED');
}
