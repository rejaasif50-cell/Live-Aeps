<?php
declare(strict_types=1);
require_once __DIR__ . '/../config.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'httponly' => true,
        'secure' => $secure,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}
function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function url(string $path = ''): string {
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}
function redirect(string $path): never {
    header('Location: ' . url($path));
    exit;
}
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function verify_csrf(): void {
    $sent = $_POST['csrf_token'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        http_response_code(419);
        exit('Session security token expired. Go back and try again.');
    }
}
function flash(string $kind, string $message): void {
    $_SESSION['flash'] = ['kind' => $kind, 'message' => $message];
}
function get_flash(): ?array {
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return is_array($f) ? $f : null;
}
function current_user(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    $stmt = db()->prepare('SELECT id, name, email, role, status, parent_id, retailer_code, commission_rate, created_at FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([(int)$_SESSION['user_id']]);
    $user = $stmt->fetch();
    if (!$user || $user['status'] !== 'active') {
        unset($_SESSION['user_id']);
        return null;
    }
    return $user;
}
function require_login(): array {
    $user = current_user();
    if (!$user) {
        flash('error', 'Please sign in to continue.');
        redirect('login.php');
    }
    return $user;
}
function require_admin(): array {
    $user = require_login();
    if (!in_array($user['role'], ['admin','manager','support'], true)) { http_response_code(403); exit('Forbidden'); }
    return $user;
}
function require_role(array $roles): array {
    $user = require_login();
    if (!in_array($user['role'], $roles, true)) { http_response_code(403); exit('Forbidden'); }
    return $user;
}
function can_manage_users(array $u): bool { return in_array($u['role'], ['admin','manager'], true); }
function audit(string $action, string $details): void {
    try { $q=db()->prepare('INSERT INTO audit_log(actor_id,action,details) VALUES(?,?,?)'); $q->execute([$_SESSION['user_id'] ?? null,$action,substr($details,0,500)]); } catch (Throwable $e) {}
}
function log_notification(?int $userId, string $channel, string $recipient, string $subject, string $message, string $status='QUEUED'): void {
    $message = preg_replace('/([?&]token=)[A-Fa-f0-9]{32,}/', '$1[REDACTED]', $message) ?? '[message redacted]';
    $q=db()->prepare('INSERT INTO notification_log(user_id,channel,recipient,subject,message,status) VALUES(?,?,?,?,?,?)'); $q->execute([$userId,$channel,$recipient,$subject,$message,$status]);
}
function notify_email(?int $userId, string $email, string $subject, string $message): void {
    $status='DISABLED'; if (defined('EMAIL_ENABLED') && EMAIL_ENABLED) { $status=@mail($email, $subject, $message, 'Content-Type: text/plain; charset=UTF-8') ? 'SENT' : 'FAILED'; }
    log_notification($userId,'email',$email,$subject,$message,$status);
}
function create_demo_ledger_note(int $userId, string $reference, string $description): void {
    $q=db()->prepare("INSERT INTO wallet_ledger(user_id,entry_type,amount,reference_code,description,mode) VALUES(?,?,?,?,?,'DEMO')"); $q->execute([$userId,'NOTE',0,$reference,$description]);
}
function money(int|float|string $amount): string {
    return '₹' . number_format((float)$amount, 2);
}
