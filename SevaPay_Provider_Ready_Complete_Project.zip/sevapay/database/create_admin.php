<?php
/*
 * Run once from the command line after importing schema.sql:
 * php database/create_admin.php
 * Delete this script after creating the first admin.
 */
require_once __DIR__ . '/../includes/bootstrap.php';
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("Run this script from the command line only.\n");
}
$name = trim(readline('Admin name: '));
$email = strtolower(trim(readline('Admin email: ')));
$password = readline('Admin password (10+ chars): ');
if (mb_strlen($name) < 2 || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 10) {
    fwrite(STDERR, "Invalid input. Name, valid email and password of at least 10 characters are required.\n");
    exit(1);
}
$stmt = db()->prepare("INSERT INTO users (name,email,password_hash,role,status) VALUES (?,?,?,'admin','active')");
try {
    $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
    echo "Admin created successfully. Delete database/create_admin.php now.\n";
} catch (PDOException $ex) {
    fwrite(STDERR, "Could not create admin. The email may already exist or database setup may be incomplete.\n");
    exit(1);
}
