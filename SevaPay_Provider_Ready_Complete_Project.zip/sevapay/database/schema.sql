CREATE DATABASE IF NOT EXISTS sevapay CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sevapay;
CREATE TABLE IF NOT EXISTS users (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL, role VARCHAR(30) NOT NULL DEFAULT 'user',
 status ENUM('active','disabled') NOT NULL DEFAULT 'active',
 parent_id BIGINT UNSIGNED NULL, retailer_code VARCHAR(24) NULL UNIQUE,
 commission_rate DECIMAL(5,2) NOT NULL DEFAULT 0.00,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_users_parent(parent_id), CONSTRAINT fk_users_parent FOREIGN KEY(parent_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
ALTER TABLE users MODIFY role VARCHAR(30) NOT NULL DEFAULT 'user';
ALTER TABLE users ADD COLUMN IF NOT EXISTS parent_id BIGINT UNSIGNED NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS retailer_code VARCHAR(24) NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS commission_rate DECIMAL(5,2) NOT NULL DEFAULT 0.00;
CREATE TABLE IF NOT EXISTS demo_transactions (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 service VARCHAR(60) NOT NULL, reference_code VARCHAR(32) NOT NULL UNIQUE,
 amount DECIMAL(12,2) NOT NULL DEFAULT 0.00, status VARCHAR(30) NOT NULL DEFAULT 'DEMO ONLY',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_demo_transactions_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_demo_user_created(user_id,created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS support_tickets (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 subject VARCHAR(140) NOT NULL, category ENUM('Account','Demo service','Technical issue','Other') NOT NULL DEFAULT 'Other',
 message TEXT NOT NULL, admin_reply TEXT NULL, status ENUM('Open','In Progress','Resolved') NOT NULL DEFAULT 'Open',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_support_tickets_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_tickets_user_updated(user_id,updated_at), INDEX idx_tickets_status_updated(status,updated_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS wallet_ledger (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 entry_type ENUM('DEMO_CREDIT','DEMO_DEBIT','NOTE') NOT NULL DEFAULT 'NOTE', amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
 reference_code VARCHAR(40) NOT NULL, description VARCHAR(255) NOT NULL,
 mode ENUM('DEMO') NOT NULL DEFAULT 'DEMO', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_wallet_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_wallet_user_date(user_id,created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS notification_log (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NULL,
 channel ENUM('email','sms','system') NOT NULL, recipient VARCHAR(190) NOT NULL,
 subject VARCHAR(190) NOT NULL, message TEXT NOT NULL, status VARCHAR(30) NOT NULL DEFAULT 'QUEUED',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_notification_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
 INDEX idx_notifications_date(created_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS password_resets (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE, expires_at DATETIME NOT NULL, used_at DATETIME NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_reset_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_reset_expiry(expires_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS provider_configs (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, provider_name VARCHAR(100) NOT NULL,
 service VARCHAR(60) NOT NULL, endpoint_url VARCHAR(255) NULL, enabled TINYINT(1) NOT NULL DEFAULT 0,
 mode ENUM('DISABLED','SANDBOX') NOT NULL DEFAULT 'DISABLED', notes VARCHAR(255) NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS audit_log (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, actor_id BIGINT UNSIGNED NULL,
 action VARCHAR(100) NOT NULL, details VARCHAR(500) NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_audit_actor FOREIGN KEY(actor_id) REFERENCES users(id) ON DELETE SET NULL,
 INDEX idx_audit_date(created_at)
) ENGINE=InnoDB;


-- REST API access keys (only hashed keys are stored)
CREATE TABLE IF NOT EXISTS api_keys (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 key_prefix VARCHAR(16) NOT NULL,
 key_hash CHAR(64) NOT NULL UNIQUE,
 scope ENUM('read','demo') NOT NULL DEFAULT 'read',
 status ENUM('active','revoked') NOT NULL DEFAULT 'active',
 created_by BIGINT UNSIGNED NULL,
 last_used_at DATETIME NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_api_keys_creator FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL,
 INDEX idx_api_keys_status(status)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS api_request_logs (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 api_key_id BIGINT UNSIGNED NULL,
 endpoint VARCHAR(190) NOT NULL,
 http_method VARCHAR(10) NOT NULL,
 response_code SMALLINT UNSIGNED NOT NULL,
 request_id VARCHAR(40) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_api_log_key FOREIGN KEY(api_key_id) REFERENCES api_keys(id) ON DELETE SET NULL,
 INDEX idx_api_logs_date(created_at), INDEX idx_api_logs_key(api_key_id,created_at)
) ENGINE=InnoDB;


-- Provider transaction journal: create only when a specific authorized adapter is implemented.
CREATE TABLE IF NOT EXISTS provider_transactions (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 service VARCHAR(40) NOT NULL,
 client_reference VARCHAR(128) NOT NULL,
 provider_reference VARCHAR(160) NULL,
 idempotency_key VARCHAR(128) NOT NULL,
 amount DECIMAL(12,2) NOT NULL,
 currency CHAR(3) NOT NULL DEFAULT 'INR',
 status ENUM('CREATED','PENDING','SUCCESS','FAILED','UNKNOWN','REVERSED') NOT NULL DEFAULT 'CREATED',
 request_hash CHAR(64) NOT NULL,
 provider_message VARCHAR(500) NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_provider_tx_idempotency(user_id,idempotency_key),
 UNIQUE KEY uq_provider_tx_client_ref(client_reference),
 UNIQUE KEY uq_provider_tx_provider_ref(provider_reference),
 INDEX idx_provider_tx_user_created(user_id,created_at),
 INDEX idx_provider_tx_status_created(status,created_at),
 CONSTRAINT fk_provider_tx_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE RESTRICT
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS provider_webhook_events (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 provider_name VARCHAR(100) NOT NULL,
 event_id VARCHAR(190) NOT NULL,
 provider_reference VARCHAR(160) NOT NULL,
 normalized_status VARCHAR(40) NOT NULL,
 payload_hash CHAR(64) NOT NULL,
 verified TINYINT(1) NOT NULL DEFAULT 0,
 processed_at DATETIME NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_provider_webhook_event(provider_name,event_id),
 INDEX idx_provider_webhook_reference(provider_reference,created_at)
) ENGINE=InnoDB;
