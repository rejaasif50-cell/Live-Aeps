# SevaPay Plus — PHP + MySQL starter

Original SevaPay-branded portal starter; not affiliated with Dhanlaxmi Agencies. This is a development/demo project, not a production financial platform.

## Added features
- User profile, support tickets, demo service requests and searchable history.
- **Demo wallet ledger:** zero-value notes only. No spendable balance, deposits, withdrawals, settlement or funds movement.
- **Retailer management:** retailer accounts/codes, parent metadata and illustrative commission percentages. No commission is calculated or paid.
- **Notifications:** notification log, email delivery gated by `EMAIL_ENABLED` (off by default), SMS adapter stub (off by default).
- **Password reset:** random single-use token, hashed at rest, expiry and password update. In local mode, the reset link is shown to facilitate testing; never enable that behavior in a public environment.
- **Reports:** date filters, service breakdown and CSV export, all demo records only.
- **Multi-level roles:** admin, manager, support, retailer, user. Admin can assign roles; manager can access reports/retailer directory; support can access admin area/support workflow.
- **REST API:** working API-key authentication, hashed-key storage, key revocation, request logs, JSON health/services endpoints and a demo-request endpoint. Demo API never calls a financial provider.
- **Provider integration framework:** provider metadata plus documented integration boundary; no live financial provider calls until a specific authorized provider adapter is implemented.
- **PWA/mobile style:** manifest, installable-app metadata, service worker for static assets and responsive UI.
- CSRF protection on state-changing forms, PDO prepared statements, password hashing, session ID regeneration, audit log.

## Install on Windows / XAMPP
1. Install XAMPP and start Apache and MySQL.
2. Extract the ZIP and copy the project folder to `C:\xampp\htdocs\sevapay`.
3. Open `http://localhost/phpmyadmin` and import `database/schema.sql` into MySQL. The schema creates/adds tables/fields used by this version. If upgrading an older MySQL/MariaDB install, take a database backup first. `ADD COLUMN IF NOT EXISTS` is supported by current MariaDB; if your MySQL version rejects that syntax, use a current XAMPP/MariaDB release or apply the column changes manually after checking `SHOW COLUMNS FROM users`.
4. Edit `config.php`: set `BASE_URL` to `/sevapay`, and adjust database credentials if needed. Keep `EMAIL_ENABLED`, `SMS_ENABLED` and `PROVIDER_API_ENABLED` false for local testing.
5. In Command Prompt run:
   ```bat
   cd C:\xampp\htdocs\sevapay
   C:\xampp\php\php.exe database\create_admin.php
   ```
   Use a unique admin email and a strong password of at least 10 characters.
6. Delete `database\create_admin.php` once the initial admin is created.
7. Visit `http://localhost/sevapay/` and log in.

## Role overview
- `admin`: all admin tools, role management, provider metadata.
- `manager`: reports and retailer management.
- `support`: admin area access intended for support ticket work.
- `retailer`: retailer account role.
- `user`: standard account.

Only admins should be able to change roles or configure provider metadata. Review and test every permission before deployment.

## Notifications and password reset
- Email is off by default. PHP `mail()` requires a correctly configured mail transport; for production use a reputable SMTP/API mail provider and a reviewed adapter.
- SMS is a disabled stub and does not send messages. Implement a vetted SMS provider adapter before use.
- Password-reset links are single-use and expire after `RESET_TOKEN_MINUTES`. For local development, the link is displayed on the page while email is disabled; do not expose that behavior publicly. Configure email delivery before public deployment.

## Working REST API (demo-only)
1. Import the updated `database/schema.sql` (back up existing data first; it adds `api_keys` and `api_request_logs`).
2. Sign in as admin and open `admin/api-keys.php` or use the **API Keys** navigation link.
3. Create a **Read** key for GET endpoints or **Demo** key to also call the demo-request endpoint. Copy the key at creation; it is shown only once. Only a SHA-256 hash is stored in MySQL.
4. Endpoints (send `X-API-Key: YOUR_KEY`):
   - `GET /sevapay/api/v1/health.php` — authenticated health check.
   - `GET /sevapay/api/v1/services.php` — list demo services.
   - `POST /sevapay/api/v1/demo-request.php` with `Content-Type: application/json` and body `{"service":"recharge"}` — creates a demo response with amount `0.00`; no DB financial transaction and no external provider call.
5. Review recent requests and revoke keys in the API Keys page. Never commit keys into source control. Use HTTPS for any non-local environment.

This is a working local REST API simulator, not a real financial-provider integration. The demo endpoint intentionally does not accept amounts, account numbers, Aadhaar data, OTPs, PINs or bank credentials.

## Provider integration boundary
`admin/providers.php` stores provider metadata only. It does not make network calls or store API keys. Before integrating a real service, obtain a contract and production credentials from an authorized provider, implement provider-specific request signing, timeouts, idempotency, reconciliation, webhook signature validation, audit logs and failure handling, and complete compliance/security review. Do not switch live services on merely by setting a config flag.

## Demo-only financial boundary
- No real money transfer, AEPS, recharge, bill payment, wallet balance, deposit, withdrawal, settlement or commission payout.
- Demo request amounts are always `0.00` and status is `DEMO ONLY`.
- Wallet ledger contains zero-value notes only and must not be treated as a balance.
- Never collect or store Aadhaar authentication secrets, OTPs, UPI PINs, card PINs or banking passwords.

## Before any public deployment
This is not production-ready. Use HTTPS, environment-managed secrets, rate limiting, email verification, MFA for privileged accounts, robust audit/monitoring, backups, least-privilege DB credentials, secure mail/SMS provider adapters, CSP/security headers and independent penetration testing. Review authorization on every route, including retailer ownership and role changes. Run only after legal/privacy/regulatory review appropriate to the services offered.

## Troubleshooting
- Database connection error: check MySQL is running and `config.php` credentials.
- 404: confirm the folder is `C:\xampp\htdocs\sevapay` and `BASE_URL` is `/sevapay`.
- Missing PDO MySQL or mbstring: enable the PHP extensions in `php.ini` and restart Apache.
- PWA install requires HTTPS in production; localhost is normally treated as secure for development.


## Actual provider integration status (important)
This package is **provider-ready, not connected to a live financial provider**. No provider was selected and no provider credentials/documentation were supplied, so the project intentionally cannot execute real recharge, DTH, money transfer, AEPS or BBPS transactions. Do not represent it as live.

### New provider API endpoints
- `POST /sevapay/api/v1/transactions.php` — provider-backed initiation boundary. It returns HTTP `503 provider_not_configured` until an authorized provider-specific adapter is implemented and enabled. Requires `X-API-Key`, JSON and an `Idempotency-Key` when an adapter is installed. It rejects common secret/auth fields such as OTP, Aadhaar/PID data, PINs and passwords.
- `GET /sevapay/api/v1/transaction-status.php?reference=...` — provider status-check boundary; returns 503 while no adapter is configured.
- `POST /sevapay/api/v1/provider-webhook.php` — webhook boundary; rejects requests while no provider signature-verifier adapter is configured.
- `providers/ProviderAdapterInterface.php` documents the required initiate/status/webhook-verification methods. `providers/ProviderRegistry.php` fails closed unless `PROVIDER_API_ENABLED` is true and `providers/ActiveProviderAdapter.php` exists and implements the interface.

### To turn on a real service
1. Select a provider authorized to offer the exact services you need in India (Mobile/DTH recharge, domestic money transfer, AEPS and BBPS may require different approvals/contracts and sometimes different providers).
2. Obtain official API documentation, sandbox credentials, production approval, signing rules, status/reconciliation rules, webhook signature specification, allowed IPs and commercial terms directly from that provider.
3. Implement `providers/ActiveProviderAdapter.php` specifically to those docs. Keep credentials outside web root and source control (environment/secret manager); do not add credentials to the admin notes page or chat.
4. Implement request signing, TLS verification, strict timeouts, response schema validation, idempotency/retry rules, status reconciliation, webhook signature/timestamp/replay verification and event deduplication. Persist the transaction journal and verified webhook events transactionally; never mark success based solely on a client response.
5. Test in provider sandbox and have the provider/security reviewer approve before production. Only then change `PROVIDER_API_ENABLED` using deployment configuration and add the relevant provider secrets to server environment. This starter config constant is deliberately false by default; do not flip it before the adapter exists and is reviewed.

The new schema includes a provider transaction journal and webhook-event table as an integration foundation. The generic endpoints do not write fake financial transactions or move money. No API secret is stored in this project. For AEPS, use the authorized provider's approved secure device/SDK flow; do not collect or persist Aadhaar authentication secrets, biometric PID data, OTPs, UPI PINs or banking passwords in this portal.
