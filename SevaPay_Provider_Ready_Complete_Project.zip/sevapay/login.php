<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (current_user()) redirect(current_user()['role']==='support' ? 'admin/tickets.php' : (in_array(current_user()['role'], ['admin','manager'], true) ? 'admin/index.php' : 'user/index.php'));
$pageTitle = 'Sign in';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    $stmt = db()->prepare('SELECT id, password_hash, status FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $row = $stmt->fetch();
    if ($row && $row['status'] === 'active' && password_verify($password, $row['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$row['id'];
        audit('login_success','User #'.(int)$row['id'].' signed in');
        $role = db()->prepare('SELECT role FROM users WHERE id=?'); $role->execute([(int)$row['id']]);
        $roleName=$role->fetchColumn(); redirect($roleName==='support' ? 'admin/tickets.php' : (in_array($roleName, ['admin','manager'], true) ? 'admin/index.php' : 'user/index.php'));
    }
    $error = 'Invalid email or password.';
}
$pageTitle = 'Sign in';
require __DIR__ . '/includes/header.php';
?>
<div class="auth-wrap"><section class="auth-card"><span class="modal-logo">S</span><span class="eyebrow">PARTNER ACCESS</span><h1 class="auth-title">Welcome back</h1><p class="muted">Sign in to your SevaPay account.</p>
<?php if ($error): ?><div class="flash error"><?= e($error) ?></div><?php endif; ?>
<form method="post" class="form-stack">
<input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<label>Email address<input type="email" name="email" autocomplete="username" required maxlength="190" placeholder="you@example.com"></label>
<label>Password<input type="password" name="password" autocomplete="current-password" required></label>
<button class="btn primary full" type="submit">Sign in →</button>
</form><p><a href="<?= e(url('forgot-password.php')) ?>">Forgot password?</a></p><p class="muted small">New partner? <a class="inline-link" href="<?= e(url('register.php')) ?>">Create an account</a></p>
</section></div>
<?php require __DIR__ . '/includes/footer.php'; ?>
